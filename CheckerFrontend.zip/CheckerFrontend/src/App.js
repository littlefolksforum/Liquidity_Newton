import React from 'react';
import Header from './components/Header.js'
import Groupholder from './components/Groupholder.js'
import Table from './components/Table.js'
import Approve from './components/Approve.js'
import axios from 'axios'
class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {

      allRequests: [],
      // Id: ""
    }

    this.methodApp = this.methodApp.bind(this)
    this.Approve = this.Approve.bind(this)
    this.Reject = this.Reject.bind(this)
  }


  componentDidMount() {
    axios.get("http://localhost:8989/checker/requests")
      .then(res => {
        this.setState({
          allRequests: res.data,
          Id: res.data[0].customerId
        })
      })
      .catch(err => {
        //this.setState({ errors: err })
      });
  }


  methodApp(customerId) {
    this.setState({ Id: customerId })

  }

  Approve(result, comment) {
    console.log(comment);
    axios.put("http://localhost:8989/checkerResponse/" + this.state.Id + "/" + result + "/" + comment)
      .then(res => {
        // this.setState({allRequests:res.data
        // })
        console.log("put method  all request: updated the checker response table (0/1) :" + res.data)
        axios.get("http://localhost:8989/checker/requests")
          .then(res => {
            this.setState({
              allRequests: res.data,
              Id: res.data[0].customerId
            })
            console.log("get method")
          })
          .catch(err => {
            //this.setState({ errors: err })
          });
      })
      .catch(err => {
        //this.setState({ errors: err })
      });
  }

  Reject(result, comment) {

    console.log(comment);
    axios.put("http://localhost:8989/checkerResponse/" + this.state.Id + "/" + result + "/" + comment)
      .then(res => {
        // this.setState({allRequests:res.data
        // })
        console.log("put method  all request: updated the checker response table (0/1) :" + res.data)
        axios.get("http://localhost:8989/checker/requests")
          .then(res => {
            this.setState({
              allRequests: res.data,
              Id: res.data[0].customerId
            })
            console.log("get method")
          })
          .catch(err => {
            //this.setState({ errors: err })
          });
      })
      .catch(err => {
        //this.setState({ errors: err })
      });

  }
  render() {
    return (
      <div>
        <div >
          <Header></Header>
        </div >
        <div className={"display"}>
          <div className={"groupholder"}>
            <Groupholder methodApp={this.methodApp}
              allRequests={this.state.allRequests}
            ></Groupholder>
          </div>
          <div className={"holder"}>
            <div>
              <Table Id={this.state.Id}></Table>
            </div>
            <div className={"approvecontainer"}>
              <Approve Approve={this.Approve}
                Reject={this.Reject}
              ></Approve>
            </div>
          </div>
        </div>
      </div>
    );
  }
}



export default App;
