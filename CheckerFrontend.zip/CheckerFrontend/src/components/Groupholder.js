import React from 'react';
import Groups from './Groups'
import axios from 'axios'
class Groupholder extends React.Component {
  customerId;
  constructor(props){
      super(props);
      this.state = {
          dataset: []
      }
      this.methodGroupholder = this.methodGroupholder.bind(this)
  }


  methodGroupholder(customerId)
  {
    this.props.methodApp(customerId);
  }
  render() {
    return (
      <div style={this.containerStyle}>
        {this.props.allRequests.map((content) => (
          <Groups
          content={content} 
          methodGroupholder={this.methodGroupholder}
          />
        ))}
      </div>
    );
  }
}



export default Groupholder;
