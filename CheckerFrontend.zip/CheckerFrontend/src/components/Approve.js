import React from 'react';
import './components.css';
import { Textfield } from 'foundation-components-core';
import { Button } from 'foundation-components-core';

class Approve extends React.Component {

    constructor(props){
        super(props);
        this.onApprove = this.onApprove.bind(this)
        this.onReject = this.onReject.bind(this)
    }

    onApprove()
    {
        this.props.Approve("A",document.getElementById('Comment').value)
        document.getElementById('Comment').value="Comment Here"
    }

    onReject()
    {
        this.props.Reject("R",document.getElementById('Comment').value)
        document.getElementById('Comment').value="Comment Here"
    }
   
    render() {
        return (
            <div>
                <div  class="commentandbonusvalueholder">
                    <div className="backgroundAdditional8" style={{ marginLeft:"0px", width: "50%" }} >
                        <Textfield 
                        defaultValue="Comment Here"
                        id="Comment"
                        
                        />
                    </div>
                    
                </div>
                <div >
                    <button class="approvebutton "  onClick={this.onApprove} style={{ alignContent: "center", marginLeft: "75%" }} >
                        <span style={{ fontSize: "16px", alignContent: "center", marginLeft: "5px" }}>Approve</span>
                    </button>
                    <button class="approvebutton "  onClick={this.onReject} style={{ alignContent: "center",marginLeft:"4%"}}>
                        <span style={{ fontSize: "16px", alignContent: "center", marginRight: "5px" }}>Reject</span>
                    </button>
                </div>
            </div>

        );
    }
}
export default Approve;
