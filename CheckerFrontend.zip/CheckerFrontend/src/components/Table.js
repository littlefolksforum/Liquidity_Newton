import React, { Component } from 'react'
import ReactTable from 'react-table'
import axios from 'axios'
import 'react-table/react-table.css'
//import {Container } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import CheckModal from './Modal'

export class Table extends Component {

  columns = [
    {

      Header: "ACCOUNT NUMBER",
      accessor: "accountId",
    },
    {
      Header: 'GROUP ID',
      accessor: 'groupId'
    },
    {
      Header: 'QUALIFIER DETAILS',
      accessor: 'qualifierValue',
      Cell: row => (<CheckModal detail={row['original']['qualifierValue']} bonus={row['original']['bonusValue']} >{console.log("row value is :" + JSON.stringify(row['original']['qualifierValue']))}
      </CheckModal>)
    },
    {
      Header: 'PRODUCT NAME',
      accessor: 'productName'
    },

  ]

  constructor(props) {
    super(props);
    this.state = {
      style: {
        cursor: "pointer",
        fontSize: "15px",
        padding: "0",
        textAlign: "center",
        userSelect: "none",
      },
      rows: [],
    }
  }



  onLoad() {
    axios.get("http://localhost:8989/checker/requests/" + this.props.Id)
      .then(res => {
        this.setState({
          // ...this.state,
          rows: res.data
        })
        console.log(res.data)
      })
      .catch(err => {
        //this.setState({ errors: err })
      });
    return this.state.rows
  }

  // onRowClick = (rowInfo) => {
  //   return {
  //     onClick: e => { this.currRow = rowInfo['original']; }
  //   };
  // }



  render() {
    return (
      <div >
        <div class="col-md-12" style={{ borderRadius: "5px", marginBottom: "12px", backgroundImage: "linear-gradient(to right, #0072AA , #21AA47) " }}>
          <div align="center"> <span style={{ fontSize: "30px", alignContent: "center" }}> Checker Portal</span></div>
        </div>
        <h6>{console.log(this.props.Id)}</h6>
        <div  >
          <ReactTable
            data={this.state.rows}
            resolveData={() => this.onLoad()}
            columns={this.columns}
            style={this.state.style}
            className="-striped -highlight tableholder"
            showPageSizeOptions={false}
            defaultPageSize={8}
            showPagination={false}
            
          />
        </div>
      </div>


    )
  }
}

export default Table;

