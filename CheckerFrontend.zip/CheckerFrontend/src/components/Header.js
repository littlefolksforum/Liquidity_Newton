import React from 'react'
import './components.css'
import Logo from 'foundation-components-logo'


class Header extends React.Component {

    render() {
        return (
            <div class = "headertextcontainer"align="center">
             <Logo />
            </div>
        )
    }
}

export default Header;