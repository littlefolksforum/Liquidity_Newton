import React from 'react'
import './components.css'
// import axios from 'axios'

class Groups extends React.Component {
    customerId = this.props.content.customerId;
    constructor(props){
        super(props);
        this.state = {
            dataset: []
        }
        this.onCheck = this.onCheck.bind(this)
    }

   

    onCheck() {
        console.log("inside onclick customerId : " + this.customerId);
        this.props.methodGroupholder(this.props.content.customerId)
    }
    render() {
        return (
            <div >
                <button class="group" onClick={this.onCheck} >
                    <span style={{ fontSize: "16px", alignContent: "center" }}>Request Id: {this.props.content.requestId}</span>
                </button>
            </div>
        )
    }
}

export default Groups;