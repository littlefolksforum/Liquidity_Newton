import React from 'react';
import Modal from 'react-modal';
//import CheckListForm from '../components/CheckListForm'

const customStyles = {
    content: {
        width: '750px',
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        height: '50vh',
        backgroundColor: '#b2dfdb'
    }
};


class CheckModal extends React.Component {
    constructor() {
        super();

        this.state = {
            modalIsOpen: false
        };

        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    componentDidMount() {
        console.log("Modal props detail :" + this.props.detail);
    }

    openModal() {
        this.setState({ modalIsOpen: true });
    }

    afterOpenModal() {
        // references are now sync'd and can be accessed.
        this.subtitle.style.color = 'Black';
        this.subtitle.style.alignItems = 'center'
    }

    closeModal() {
        this.setState({ modalIsOpen: false });
    }

    render() {

        return (

            <div >
                <button type="button" onClick={this.openModal} >Details</button>
                <Modal
                    isOpen={this.state.modalIsOpen}
                    //onAfterOpen={this.afterOpenModal}
                    onRequestClose={this.closeModal}
                    style={customStyles}
                    contentLabel="Example Modal"
                >
                    <div>
                        <div style={{ alignContent: "center", marginLeft: "250px" }}>
                            <span style={{ fontSize: "20px", alignContent: "center" }}> Qualifier Details</span>
                        </div>
                        <div>
                            <span style={{ fontSize: "20px", alignContent: "center" }}>{this.props.detail}</span>
                        </div>
                        <div style={{ alignContent: "center", marginLeft: "250px" }}>
                            <span style={{ fontSize: "20px", alignContent: "center" }}> Bonus Details</span>
                        </div>
                        <div>
                            <span style={{ fontSize: "20px", alignContent: "center" }}>{this.props.bonus}</span>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}
export default CheckModal;


