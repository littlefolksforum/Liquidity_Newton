package com.scb.newton.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.newton.bean.CheckerRequests;
import com.scb.newton.bean.CheckerTableData;

@CrossOrigin(origins = "*")
@RestController
public class CheckerRequestController {

	@Autowired
	JdbcTemplate jtemplate;
	private static String listRequests = " select requestId,customerId from checkerPortal where requested='N' ORDER BY requestId";
	// to insert data dynamically we use Prepared statement
	// following is the syntax of preparedStatemrnt

	private static String addUserLogin = "insert into userlogin values(?,?,?)";

	private static String deleteUser = "delete from UserLogin where userName = ?";
	private static String checkerResponse = "update checkerPortal set requested='Y', result=?,checkerComment=? where customerId=?";

	// Getting the request list
	@GetMapping("/checker/requests")
	public List<CheckerRequests> getAllCheckerRequests()

	{
		List<CheckerRequests> requests = new ArrayList<CheckerRequests>();
		List<Map<String, Object>> rows = jtemplate.queryForList(listRequests);

		for (Map<String, Object> row : rows) {
			CheckerRequests rq = new CheckerRequests();
			rq.setRequestId((int) row.get("requestId"));
			rq.setCustomerId((String) row.get("customerId"));
			requests.add(rq);
		}
		return requests;
	}

	// fetching data for a particular customer
	@GetMapping("/checker/requests/{customerId}")
	public List<CheckerTableData> getAllTableData(@PathVariable String customerId) {

		List<CheckerTableData> data = new ArrayList<CheckerTableData>();
		String sql = "select accountId from accountInfo where customerId=";
		List<Map<String, Object>> rows = jtemplate.queryForList(sql + "'" + customerId + "'");

		for (Map<String, Object> row : rows) {
			CheckerTableData td = new CheckerTableData();
			td.setAccountId((String) row.get("accountId"));
			td.setGroupId(groupIdFromaccountId(td.getAccountId()));
			td.setQualifierId(qualifierIdFromproductId(productIdFromgroupId(td.getGroupId())));
			td.setQualifierValue(qualifierValueFromproductId(productIdFromgroupId(td.getGroupId())));
			td.setProductName(productNameFromproductId(productIdFromgroupId(td.getGroupId())));
			String productId=productIdFromgroupId(td.getGroupId());
			td.setBonusValue(bonusValueFromproductId(productId));
			data.add(td);

		}
		return data;
	}

	String groupIdFromaccountId(String accountId) {
		String sql = "select groupId from accountInfo where accountId=" + "'" + accountId + "'";
		String groupId = (String) jtemplate.queryForObject(sql, String.class);
		return groupId;
	}

	String productIdFromgroupId(String groupId) {
		String sql = "select productId from groupInfo where groupId=" + "'" + groupId + "'";
		String productId = (String) jtemplate.queryForObject(sql, String.class);
		return productId;
	}

	String qualifierIdFromproductId(String productId) {
		String sql = "select qualifierId from qualifierInfo where productId=" + "'" + productId + "'";
		String qualifierId = "";
		List<Map<String, Object>> rows = jtemplate.queryForList(sql);

		for (Map<String, Object> row : rows) {

			String s = (String) row.get("qualifierId");
			qualifierId = qualifierId + s + ",";
		}
		return qualifierId;
	}

	String qualifierValueFromproductId(String productId) {
		String sql = "select qualifierId from qualifierInfo where productId=" + "'" + productId + "'";
		List<Map<String, Object>> rows = jtemplate.queryForList(sql);
		String qualifierValue = "";
		System.out.println(qualifierValue);
		for (Map<String, Object> row : rows) {
			System.out.println("in for loop");
			String s = (String) row.get("qualifierId");
			System.out.println(s + "condition value");
			String query = "select qualifierValue from qualifierInfo where qualifierId=" + "'" + s + "'";
			Integer quali = (Integer) jtemplate.queryForObject(query, Integer.class);
			String qualifier = quali.toString();
			System.out.println("condition check");
			String detail="";
			if(s.equals("Q1"))
			{
				detail ="Average balance of all accounts in the group should be greater than or equal to ";
				
			}
			if(s.equals("Q2"))
			{
				detail = "Minimum value of daily account balance including all accounts should be greater than or equal to ";
				
			}
			if(s.equals("Q3"))
			{
			detail= "Balance growth value of all accounts in the group should be more than ";
			
			}
			if(s.equals("Q4"))
			{
				detail= "Total number of transactions of all accounts in the group should be more than ";
				
			}
		    
			qualifierValue = qualifierValue+s+":"+detail+"Rupees "+qualifier+",  ";
			
			System.out.println(detail);
		}

		return qualifierValue;
	}
	

	String bonusValueFromproductId(String productId) {
		String sql = "select bonusId,bonusValue from productInfo where productId=" + "'" + productId + "'";
		List<Map<String, Object>> rows=  jtemplate.queryForList(sql);
		String s="";
		int v=0;
		String req="";
		String details="";
		for(Map<String, Object> row:rows) {
			s=(String)row.get("bonusId");
			v=(int)row.get("bonusValue");
			req= Integer.toString(v);
		}
		
		if(s.equals("B1"))
		{
			details="Bonus percentage of the total balance at the end of the month is ";
		}
		

		if(s.equals("B2"))
		{
			details="If all qualifiers are met, bonus value is fixed to ";
		}
		
		return s+":"+details+"Rupees "+req;
	}
	
	String productNameFromproductId(String productId)
	{
		String sql = "select productName from productInfo where productId=" + "'" + productId + "'";
		String productName = (String) jtemplate.queryForObject(sql, String.class);
		return productName;
	}
	


	@PutMapping("/checkerResponse/{customerId}/{result}/{checkerComment}")
	public int checkerResponse(@PathVariable("customerId") String customerId, @PathVariable("result") String result,@PathVariable("checkerComment") String checkerComment) {
		System.out.println("Inside putmapping checker response customer Id :" + customerId + " result :" + result+ "RESULT:"+checkerComment);
		return jtemplate.update(checkerResponse, result,checkerComment,customerId);
	}

//	@PostMapping("/createUser")
//	public int createUserLogin(@RequestBody UserLogin ul)
//	{
//		return jtemplate.update(addUserLogin,new Object[]
//				{ul.getUserName(),ul.getPassword(),ul.getMobile()});
//	}
//	@DeleteMapping("/deleteUser/{userName}")
//	public int deleteUserLogin(@PathVariable String userName)
//	{
//		return jtemplate.update(deleteUser,userName);
//			
//	}

}
