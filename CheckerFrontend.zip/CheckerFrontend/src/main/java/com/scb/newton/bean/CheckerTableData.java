package com.scb.newton.bean;

public class CheckerTableData {
	String accountId;
	String groupId;
	String qualifierValue;
	String qualifierId;
	String productName;
	String bonusValue;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBonusValue() {
		return bonusValue;
	}
	public void setBonusValue(String bonusValue) {
		this.bonusValue = bonusValue;
	}
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getQualifierValue() {
		return qualifierValue;
	}
	public void setQualifierValue(String qualifierValue) {
		this.qualifierValue = qualifierValue;
	}
	public String getQualifierId() {
		return qualifierId;
	}
	public void setQualifierId(String qualifierId) {
		this.qualifierId = qualifierId;
	}
}
